package com.concesionaria.concesionaria_vehiculos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConcesionariaVehiculosApplicationTests {

	@Test
	void contextLoads() {
	}

}
