package com.concesionaria.concesionaria_vehiculos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConcesionariaVehiculosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConcesionariaVehiculosApplication.class, args);
	}

}
